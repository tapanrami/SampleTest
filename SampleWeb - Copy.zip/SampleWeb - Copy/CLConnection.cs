﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace SampleWeb
{
    public class CLConnection
    {
        public static string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["DbShopConnectionString"].ConnectionString; }
        }

    }
}