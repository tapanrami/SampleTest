﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleWeb
{
    public partial class home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                using (DBDataDataContext dataContext = new DBDataDataContext(CLConnection.ConnectionString))
                {
                    Session["orders"] = dataContext.tblOrders.OrderByDescending(x => x.orderid);

                    grdOrder.DataSource = Session["orders"];
                    grdOrder.DataBind();
                };
            }

        }

        protected void btnAddOrder_Click(object sender, EventArgs e)
        {
            Response.Redirect("addOrder.aspx");
        }

        protected void grdOrder_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

            grdOrder.DataSource = Session["orders"];
            grdOrder.PageIndex = e.NewPageIndex;
            grdOrder.DataBind();

        }

        protected void grdOrder_Sorting(object sender, GridViewSortEventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            using (DBDataDataContext dataContext = new DBDataDataContext(CLConnection.ConnectionString))
            {
                var orderList = dataContext.tblOrders;

                if (txtBillNo.Text.Trim() == "" && txtBillyear.Text.Trim() == "" && txtFirstName.Text.Trim() == "" && txtLastName.Text.Trim() == "" && txtMobileNo.Text.Trim() == "")
                {
                    Session["orders"] = dataContext.tblOrders.OrderByDescending(x => x.orderid);

                    grdOrder.DataSource = Session["orders"];
                    grdOrder.DataBind();
                }
                else
                {

                    Session["orders"] = orderList.Where
                                                        (
                                                            x =>
                                                            (!string.IsNullOrEmpty(txtBillNo.Text) && !string.IsNullOrEmpty(txtBillyear.Text) &&
                                                            x.billno == txtBillNo.Text && Convert.ToString(x.billyear) == txtBillyear.Text)
                                                            ||
                                                            (!string.IsNullOrEmpty(txtFirstName.Text) && x.firstname.Contains(txtFirstName.Text))
                                                            ||
                                                            (!string.IsNullOrEmpty(txtLastName.Text) && x.lastname.Contains(txtLastName.Text))
                                                            ||
                                                            (!string.IsNullOrEmpty(txtMobileNo.Text) && x.mobileno.Contains(txtMobileNo.Text))

                                                        ).OrderByDescending(x => x.orderid);
                    grdOrder.DataSource = Session["orders"];
                    grdOrder.DataBind();
                }
            };
        }

        protected void grdOrder_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void grdOrder_RowCommand(object sender, GridViewCommandEventArgs e)
        {


            if (e.CommandName.Equals("view"))
            {
                string QueryString = "val";
                Page.ClientScript.RegisterStartupScript(GetType(), "view", "window.open('viewSubOrder.aspx?id=" + Convert.ToDecimal(grdOrder.Rows[Convert.ToInt32(e.CommandArgument.ToString())].Cells[0].Text) + "','');", true);
            }
            else
            {
                using (DBDataDataContext dataContext = new DBDataDataContext(CLConnection.ConnectionString))
                {

                    tblOrder order = new tblOrder();
                    order = dataContext.tblOrders.Where(x => x.orderid == Convert.ToDecimal(grdOrder.Rows[Convert.ToInt32(e.CommandArgument.ToString())].Cells[0].Text)).FirstOrDefault();

                    List<tblSubOrder> subOrder = new List<tblSubOrder>();
                    subOrder = order.tblSubOrders.Where(x => x.orderid == order.orderid).ToList();

                    if (subOrder != null && subOrder.Count > 0)
                    {
                        foreach (var item in subOrder)
                        {
                            dataContext.tblSubOrders.DeleteOnSubmit(item);
                            dataContext.SubmitChanges();
                        }
                    }

                    dataContext.tblOrders.DeleteOnSubmit(order);
                    dataContext.SubmitChanges();

                    btnSearch_Click(null, null);
                };
            }
        }


        protected void grdOrder_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string item = e.Row.Cells[0].Text;
                foreach (ImageButton button in e.Row.Cells[e.Row.Cells.Count - 1].Controls.OfType<ImageButton>())
                {
                    if (button.CommandName == "Delete")
                    {
                        button.Attributes["onclick"] = "if(!confirm('Are you sure you want to delete?')){ return false; };";
                    }
                }

                Label lblAmount = e.Row.Cells[7].FindControl("lblAmount") as Label;
                if (lblAmount != null)
                {
                    using (DBDataDataContext dataContext = new DBDataDataContext(CLConnection.ConnectionString))
                    {
                        var sum = dataContext.tblSubOrders.Where(x => x.orderid == decimal.Parse(item)).Sum(x => x.total);
                        if (sum > 0)
                        {
                            lblAmount.Text = string.IsNullOrEmpty(sum.ToString()) ? "0" : sum.ToString();
                        }
                        else
                        {
                            lblAmount.Text = "Order contains no items";
                        }
                    };
                }

                Label lblCompany = e.Row.Cells[7].FindControl("lblCompany") as Label;
                if (lblCompany != null)
                {
                    using (DBDataDataContext dataContext = new DBDataDataContext(CLConnection.ConnectionString))
                    {
                        tblOrder order = dataContext.tblOrders.Where(x => x.orderid == decimal.Parse(item)).FirstOrDefault();

                        tblCompany company = dataContext.tblCompanies.Where(x => x.companyid == order.companyid).FirstOrDefault();

                        lblCompany.Text = company.name.ToString();

                    };
                }
            }

        }
    }
}