﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleWeb
{
    public partial class Site : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToString(Session["username"]) != "")
            {
                lblUserName.Text = Convert.ToString(Session["username"]);
            }
            else
            {
                Response.Redirect("login.aspx");
            }
        }

        protected void lnkOrder_Click(object sender, EventArgs e)
        {
            Response.Redirect("home.aspx");
        }

        protected void lnkLogOut_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("login.aspx");
        }
    }
}