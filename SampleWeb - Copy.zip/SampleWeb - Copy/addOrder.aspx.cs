﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Caching;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleWeb
{
    public partial class addOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                using (DBDataDataContext dataContext = new DBDataDataContext(CLConnection.ConnectionString))
                {
                    var companies = dataContext.tblCompanies.ToList();

                    if (companies != null)
                    {
                        foreach (var company in companies)
                        {
                            ddlCompany.Items.Add(new ListItem(company.name, company.companyid.ToString()));
                        }
                    }
                }

                grdItemList.DataSource = null;
                grdItemList.DataBind();

                txtBillYear.Text = DateTime.Now.Year.ToString();
            }
            else
            {
                if (!string.IsNullOrEmpty(lblOrderID.Text))
                {
                    using (DBDataDataContext dataContext = new DBDataDataContext(CLConnection.ConnectionString))
                    {
                        var subOrderItemList = dataContext.tblSubOrders.Where(x => x.orderid == decimal.Parse(lblOrderID.Text));

                        grdItemList.DataSource = subOrderItemList;
                        grdItemList.DataBind();
                    }
                }
            }
        }

        protected void btnAddItems_Click(object sender, EventArgs e)
        {
            using (DBDataDataContext dataContext = new DBDataDataContext(CLConnection.ConnectionString))
            {
                var order = dataContext.tblOrders.Where(x => x.billno == txtBillNo.Text.Trim() && x.companyid.ToString() == ddlCompany.SelectedItem.Value && x.billyear == Convert.ToInt32(txtBillYear.Text.Trim()));

                if (order.Any())
                {
                    lblError.Text = "Bill no " + txtBillNo.Text.Trim() + " already exists for company " + ddlCompany.SelectedItem.Text + " for year " + txtBillYear.Text.Trim() + ".";
                }
                else
                {
                    tblOrder newOrder = new tblOrder()
                    {
                        companyid = decimal.Parse(ddlCompany.SelectedItem.Value),
                        billno = txtBillNo.Text.Trim(),
                        billyear = Convert.ToInt32(txtBillYear.Text.Trim()),
                        firstname = txtFirstName.Text.Trim(),
                        lastname = txtLastName.Text.Trim(),
                        street = txtAddress.Text.Trim(),
                        state = txtState.Text.Trim(),
                        country = txtCountry.Text.Trim(),
                        mobileno = txtMobileNo.Text.Trim(),
                        createdate = DateTime.Parse(txtOrderDate.Text.Trim()),
                    };
                    dataContext.tblOrders.InsertOnSubmit(newOrder);

                    dataContext.SubmitChanges();
                    pnlOrderDetails.Visible = true;
                    pnlOrder.Visible = false;

                    lblOrderID.Text = newOrder.orderid.ToString();
                }
            }
        }

        protected void btnAddOrder_Click(object sender, EventArgs e)
        {
            Response.Redirect("addOrder.aspx");
        }

        protected void btnAddItem_Click(object sender, EventArgs e)
        {
            using (DBDataDataContext dataContext = new DBDataDataContext(CLConnection.ConnectionString))
            {

                tblSubOrder subOrder = new tblSubOrder()
                {
                    orderid = decimal.Parse(lblOrderID.Text),
                    name = txtItemName.Text.Trim(),
                    quantity = decimal.Parse(txtQuantity.Text.Trim()),
                    price = decimal.Parse(txtPrice.Text.Trim()),
                    total = (decimal.Parse(txtQuantity.Text.Trim()) * decimal.Parse(txtPrice.Text.Trim()))
                };

                dataContext.tblSubOrders.InsertOnSubmit(subOrder);
                dataContext.SubmitChanges();

                var subOrderItemList = dataContext.tblSubOrders.Where(x => x.orderid == decimal.Parse(lblOrderID.Text));

                grdItemList.DataSource = subOrderItemList;
                grdItemList.DataBind();

                var sum = dataContext.tblSubOrders.Where(x => x.orderid == decimal.Parse(lblOrderID.Text)).Sum(x => x.total);
                lblBillAmount.Text = string.IsNullOrEmpty(sum.ToString()) ? "0" : sum.ToString();

                txtItemName.Text = "";
                txtQuantity.Text = "";
                txtPrice.Text = "";
            }
        }

        protected void grdItemList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            using (DBDataDataContext dataContext = new DBDataDataContext(CLConnection.ConnectionString))
            {

                tblSubOrder subOrder = new tblSubOrder();
                subOrder = dataContext.tblSubOrders.Where(x => x.suborderid == Convert.ToInt32(grdItemList.Rows[Convert.ToInt32(e.CommandArgument.ToString())].Cells[0].Text)).FirstOrDefault();

                //dataContext.Refresh(System.Data.Linq.RefreshMode.KeepChanges, subOrder);
                //dataContext.tblSubOrders.Attach(subOrder);
                dataContext.tblSubOrders.DeleteOnSubmit(subOrder);
                dataContext.SubmitChanges();

                var subOrderItemList = dataContext.tblSubOrders.Where(x => x.orderid == decimal.Parse(lblOrderID.Text));

                var sum = dataContext.tblSubOrders.Where(x => x.orderid == decimal.Parse(lblOrderID.Text)).Sum(x => x.total);
                lblBillAmount.Text = string.IsNullOrEmpty(sum.ToString()) ? "0" : sum.ToString();

                grdItemList.DataSource = subOrderItemList;
                grdItemList.DataBind();
            };
        }

        protected void grdItemList_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void grdItemList_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                foreach (ImageButton button in e.Row.Cells[e.Row.Cells.Count - 1].Controls.OfType<ImageButton>())
                {
                    if (button.CommandName == "Delete")
                    {
                        button.Attributes["onclick"] = "if(!confirm('Are you sure you want to delete?')){ return false; };";
                    }
                }
            }
        }
    }
}
