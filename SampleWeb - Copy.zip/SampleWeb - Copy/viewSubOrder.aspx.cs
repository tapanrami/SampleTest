﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleWeb
{
    public partial class viewSubOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString["id"]))
            {
                using (DBDataDataContext dataContext = new DBDataDataContext(CLConnection.ConnectionString))
                {
                    var subOrderItemList = dataContext.tblSubOrders.Where(x => x.orderid == decimal.Parse(Request.QueryString["id"]));

                    grdItemList.DataSource = subOrderItemList;
                    grdItemList.DataBind();
                }
            }
        }
    }
}