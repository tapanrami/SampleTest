﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace SampleWeb
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text == "" || txtPassword.Text == "")
            {
                divError.InnerHtml = "Username or password is empty.";
            }
            else
            {

                using (DBDataDataContext dataContext = new DBDataDataContext(CLConnection.ConnectionString))
                {
                    var user = dataContext.tblUsers.FirstOrDefault(x => x.username == txtUserName.Text && x.password == txtPassword.Text);

                    if (user != null)
                    {                        
                        Session["username"] = txtUserName.Text;
                        Response.Redirect("home.aspx");
                    }
                    else
                    {
                        divError.InnerHtml = "Invalid username or password.";
                    }
                }
            }
        }
    }
}